public class Player {
  private double seedMoney;  
  private final double initialMoney;
  private double betPer;
  private double losingBet;
  private double winningBet;

  // Create a class constructor for the Main class
  public Player(double lBet, double wBet) {
    seedMoney = 100.0;
    initialMoney = seedMoney;
    betPer = wBet;
    winningBet = wBet;
    losingBet = lBet;

  }

  public double getSeedMoney(){
      return seedMoney; 
  }
  
  
  public double getBetPer(){
      return betPer; 
  }
  
  public void setNewBetPer(){
    if (seedMoney < initialMoney){
        betPer = losingBet;
    }
    else{
        betPer = winningBet;
    }
  }
  
  
  /**
   * plays 50% chance gamble, double or nothing rebalances seedMoney accordingly
   * 
   * double bet is money betted on this round
   * return true if you win the gamble else false
   */
  public boolean gamble(double bet){
      boolean win = false;
      //wins half of the time
      if(Math.random() < 0.5){
          win = true;
          seedMoney += bet;
          setNewBetPer();
      }
      else{
          seedMoney = seedMoney - (bet);
          setNewBetPer();
      }
      return win;
  }

}
