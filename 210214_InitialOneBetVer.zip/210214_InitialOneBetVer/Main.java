/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
	    double averageMoney = 0;
	    double averageWin = 0; //actually sum of all wins
	    double averageProfit = 0; //actually sum of all profit
	    double averageLoss =0; //actually sum of all loss
	    int profitPlayerCounter = 0;

	    int sampleSize = 100000;
	    int sampleRound = 5;
	    
    	    for(int p = 0; p < sampleSize; p++){
    	        	Player playerOne = new Player(0.5,0.5);
    		        int i =0;
    		        
    		       //gamble for this player
    	    	    while(i < sampleRound && playerOne.getSeedMoney()>0){
        		        double betMoney = playerOne.getSeedMoney()*playerOne.getBetPer();
    	    	        if(playerOne.gamble(betMoney) == true){
    	    	            averageWin += 1.0;
    	    	        }
    		            i++;
    		      }
    		      
    		      //report of curr player
    		      if(playerOne.getSeedMoney()>=100.0){
    		          //System.out.println("final : " + playerOne.getSeedMoney()+" !profit!");
    		          profitPlayerCounter++;
    		          averageProfit += playerOne.getSeedMoney() - 100.0;
    		      }
    		      else{
    		          averageLoss += playerOne.getSeedMoney() - 100.0;
                       //System.out.println("final: " + playerOne.getSeedMoney());
    		      }
    		      
                //sum for average 
                averageMoney += playerOne.getSeedMoney();
    	    }

        //final report
	    System.out.println("Average Win Rate: "+averageWin/(sampleSize*sampleRound)); //if win rate !(0.48,0.52) then throw error
	    System.out.println("Average Final Money: " + averageMoney/(double)sampleSize);
	    System.out.println("Profited Player: " + (profitPlayerCounter/(double)sampleSize)*100 +"%");
	    if(profitPlayerCounter>0){
               
 	        System.out.println("Average Profit: " + averageProfit/profitPlayerCounter);       
	    }
   	        System.out.println("Average Loss: " + averageLoss/(sampleSize-profitPlayerCounter));     
            double totalsum =(averageProfit+averageLoss);
            System.out.println("Total Sum: " + totalsum);
	}
}
